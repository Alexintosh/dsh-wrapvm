# dsh-wrapvm

A DeepSeek Harness plugin for working in managed Docker desktop environments. Ask the agent to use a VM: it prepares an environment, copies the conversation’s project and selects it automatically. Follow its shell, Chrome and desktop work from the optional viewer.

**DeepSeek Harness 0.2.2-rc.2** · **Docker** · **Bundle 0.3.1**

- Let the agent create, start or resume an environment and prepare its project with `vm_prepare`.
- Manage environments manually from the Harness-native UI whenever useful.
- Select an environment per conversation and open its desktop in the right sidebar.
- Set CPU and memory limits, inspect resource statistics, and explicitly enable internet access for the current desktop backend.
- Keep work in a persistent workspace volume, with optional explicit host folder mounts.
- Give the agent purpose-built guest tools and six short guides for using them.

## Requirements

| Component | Requirement |
| --- | --- |
| DeepSeek Harness | 0.2.2-rc.2, running on the host with its plugin manager and web interface |
| Runtime | Node.js 24.9 or later for the Harness runtime; a GUI installation may provide its own runtime |
| Container engine | A working Docker installation and daemon accessible to Harness |
| Desktop image | A compatible Wrapvm desktop image with `/opt/wrap/bin/wrap-entrypoint`, Python 3, Chrome CDP, and `wrap-desktop` |
| Plugin | A built `@deepseek-ai/dsh-wrapvm-isolate` 0.3.1 `.tgz` bundle available to the Harness host |

The backend has been exercised with Docker on OrbStack on arm64 using a local `wrapvm-dsh:desktop` image. The upstream image is `ghcr.io/tobi/wrapvm:desktop`; its availability and compatibility depend on your installation. On macOS, Docker runs containers through its engine VM; this plugin does not create a separate VM for each environment.

## Get started

Download the [0.3.1 bundle](dist/deepseek-ai-dsh-wrapvm-isolate-0.3.1.tgz) and its [SHA-256 checksum](dist/deepseek-ai-dsh-wrapvm-isolate-0.3.1.tgz.sha256). Install the archive, not the source directory. **0.3.1 is prepared and tested separately; it has not been installed into the running desktop profile.** The previous [0.2.2 archive](dist/deepseek-ai-dsh-wrapvm-isolate-0.2.2.tgz) remains available.

1. Start Docker and ensure the configured desktop image is installed locally.
2. When ready to upgrade, use **Plugins → Add plugin** with the absolute `.tgz` path. Enable the plugin and restart Harness if requested to refresh its Remote descriptors.
3. In a conversation with the intended project, ask:

   > Load `use-vm` and prepare a VM for this project, then work inside it.

The agent calls `vm_prepare`. It creates or reuses the environment, starts/resumes it if necessary, copies the working files once, and assigns it to the conversation. **You do not need to open VM environments or select anything manually.**

Open **VM desktop** to watch the desktop if desired. Choose **Open in host browser** to open the same desktop in the Mac’s default browser, outside Harness, using its authenticated viewer link. The action is also available in Settings. If a browser blocks the automatic opening, use the **Open authenticated link** fallback. Settings offers the same viewer; **VM environments** remains available for manual lifecycle and resource controls. Both reflect agent-driven changes.

## What changed in 0.3.1

An explicit host-browser action now requests the owner-only authenticated viewer link on click. It checks the current conversation selection before opening and keeps the embedded viewer available.

### Included from 0.3.0

Automatic preparation replaces the manual setup requirement. `vm_prepare`, `vm_environments` and `vm_workspace` give the agent creation, selection and bounded file-transfer capabilities. Preparation is persisted before Docker effects; retries reuse its identity and preserve guest edits. The existing Harness-native design is retained.

## Agent tools

| Tool | Purpose |
| --- | --- |
| `vm_prepare` | Create/reuse/start/resume, prepare the current project and assign the environment to this conversation. |
| `vm_status` | Inspect state and next steps, including `unassigned`, stopped, paused and uncertain outcomes. Never creates resources. |
| `vm_environments` | List managed environments for explicit selection through `vm_prepare(environmentId)`. |
| `vm_workspace` | Inspect workspace metadata, import named files, or export named files to a new host review directory. |
| `vm_shell` | Run a command in a fresh guest login shell; the default working directory is the prepared guest project, falling back to `/home/user/workspace`. |
| `vm_browser` | Open and inspect pages, list tabs, navigate, evaluate JavaScript, and close tabs through guest Chrome. |
| `vm_desktop` | Run `agent-desktop` commands in the guest desktop session. |
| `load_vm_skill` | Load bundled guidance by name: `use-vm`, `vm-workspace`, `vm-browser`, `vm-desktop`, `vm-development`, or `vm-recovery`. |

`use-vm` is a guidance name for `load_vm_skill`, not a slash command.

## Workspace and lifecycle

Each environment has a named Docker volume mounted at `/home/user/workspace`. Stopping preserves the container and workspace. Removal shows a confirmation preview and lets you choose whether to delete the workspace volume. Explicit host mounts expose the paths you choose, read-only by default unless writing is enabled; removal does not delete those host directories. Existing unrelated or unlabeled containers are not automatically imported.

The default `copy` mode includes current working files, including uncommitted and untracked changes. It excludes `.git`, `.env*`, common credential files, dependencies, cache/build directories, symlinks and hard-linked files. The result reports omissions. Filename/content checks are conservative filters, not a guarantee that arbitrary project files contain no secrets. Git history, hooks and repository configuration are not copied.

Snapshots are limited to 5,000 files / 64 MiB, with a 2 MiB per-file cap. Oversized projects fail with an explanation; they are not silently truncated. No project yields an empty persistent workspace. Changing the conversation’s project prepares a distinct guest directory and preserves the previous one.

`vm_workspace import` adds requested files and reports differing existing guest files as conflicts; it never overwrites them. `export` writes requested guest files into a new `.wrapvm-exports/review-*` directory in the current project and reports changes to the host originals since preparation. It does **not** apply those files over the originals or propagate deletions. Review and apply them separately when appropriate.

`bind-readonly` and `bind-readwrite` share the exact session project instead of copying it. They require an actual Harness approval for that path and mode; unavailable or rejected approval refuses the mount. A mount shares the full project, including files omitted by copy mode, and cannot be added to an existing container.

Environment inventory, preparations and conversation selection are persisted by the plugin. Viewer links are issued through the owner-only Remote endpoint and are not included in `vm_status` or agent tool output. The plugin keeps them only in component memory and clears its links on selection/session changes. An external browser may retain its tab, history and authentication; closing the Harness panel does not revoke the VM’s viewer password. These loopback links are intended for a browser on the Harness host.

## Configuration

| Setting | Default | Purpose |
| --- | --- | --- |
| `backend` | `docker` | Engine executable |
| `agentImage` | `wrapvm-dsh:desktop` | Locally installed image used for automatic creation; no implicit pull |
| `agentCpuMillis` | `2000` | 2 CPU cores for newly created agent environments |
| `agentMemoryBytes` | `2147483648` | 2 GiB for newly created agent environments |
| `agentInternetAccess` | `true` | Explicit creation default; this desktop backend cannot create offline environments |
| `metricsCadenceMs` | `5000` | Shared resource sampling interval |
| `metricsStalenessMs` | `15000` | Resource staleness threshold |

These defaults apply to automatic creation. Existing environments keep their configuration. Manual creation and CPU/memory changes remain available in the UI.

## Known Limitations and Deferred Work

Harness continues to run on the host. Only the plugin's guest tools execute inside the selected container; ordinary Harness tools retain their existing permissions. Selection does not provide host-wide or complete network isolation. Disk quotas are not supported by this Docker backend. Cancelling a host-side command does not guarantee that the guest process has exited. Offline creation is rejected before allocating resources. The 0.3.x automatic workflow is tested in isolated tool, Gateway, component and Docker scenarios; its assembled UI has not been installed or checked in the user’s active profile. If the host project changes during an interrupted initial copy, preparation refuses to mix snapshots. Missing/replaced containers and uncertain outcomes require inspection rather than automatic resets. This is not a claim of host-wide isolation.

## Development

The current source, tests, generated runtime files and installable archive are included:

| Path | Contents |
| --- | --- |
| `src/index.ts` | Host service, Remote methods and guest tools |
| `src/client/` | Harness-native environment page, dialogs, session panel and viewer |
| `src/` | Docker backend, inventory, lifecycle and supporting modules |
| `tests/` | Unit, component, integration and opt-in live checks |
| `lib/` | Built host/client runtime and generated Remote declarations |
| `dist/` | Installable bundle and checksum |

The standalone development scripts use an existing compatible DSH checkout **read-only** for its toolchain. They build and test this repository without copying changes into Harness, installing a plugin or modifying a profile. See [development and validation notes](docs/DEVELOPMENT.md).

## Model, tokens and cache effects

The plugin adds eight tool definitions. Loading a guide returns only that guide; it does not create a VM. Project contents travel directly to the guest, not through model messages. Preparation returns a bounded summary of the manifest and exclusions; shell/browser output still consumes model context normally. No model settings or KV-cache policy are changed.

## Acknowledgments

Built around [Wrapvm](https://github.com/tobi/wrapvm) and [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness), whose documentation covers Harness profiles and plugin management.
