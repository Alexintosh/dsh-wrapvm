# Wrapvm desktop

The legacy Settings section shows the configured container and offers lifecycle controls. Ordinary Harness tools retain their existing access; a Docker container is not a dedicated virtual machine.

The VM environments page and VM desktop sidebar require the v0.2 Remote contribution. When it is unavailable, the UI says so. The current read-only inventory cannot establish conversation bindings until their global index is restored. The desktop remains closed while the binding is unknown, and Settings uses the same session-scoped desktop when the required Remote methods are present. The viewer is local to the host; its URL is held only for the active frame and discarded on session change, a policy or binding revision, or loss of the session stream. Client closure does not establish server-side credential revocation.

See [configuration and isolation limits](../README.md) before enabling a read/write workspace mount.

![Wrapvm desktop settings preview](preview.svg)

This illustration is a feature preview, not evidence of a live container or installed GUI test.
