---
description: "可选的 wrapvm 桌面容器层：虚拟机工具、生命周期控制、配置与隔离限制。"
kind: "package-bundle"
---

# @deepseek-ai/dsh-wrapvm-isolate

[English](README.md) | 中文

## Summary

此可选功能包添加容器工具和设置中的 Wrapvm 桌面分区。它使用本地 Docker 或 Podman 引擎以及 `ghcr.io/tobi/wrapvm:desktop` 镜像。只有 `vm_*` 工具在容器内运行；普通 Harness shell、文件系统、浏览器和计算机工具保留原有执行环境与权限。

需要 DeepSeek Harness `0.2.2-rc.2` 和 Node.js `>=24.9.0`。

## Configuration and behavior

[功能包补丁](cordis.patch.yml)插入 `wrapvm-isolate` 服务条目。默认配置不包含此功能包。配置安装不属于本文所述的组件和模拟引擎验证范围。

| 配置字段 | 功能包补丁中的默认值 | 含义 |
|---|---|---|
| `backend` | `docker` | 本地容器引擎可执行程序；也支持 `podman`。 |
| `image` | `ghcr.io/tobi/wrapvm:desktop` | 创建容器时使用的镜像。 |
| `containerName` | `wrapvm-isolate` | 要创建、检查、启动和停止的容器。 |
| `workspaceDir` | Harness 进程工作目录 | 以读写方式挂载到 `/home/user/workspace` 的主机绝对目录；省略此项可避免挂载主机工作区。 |
| `viewerPort` | `6080` | 桌面查看器的主机回环端口。 |
| `cdpPort` | `9223` | 浏览器调试端点的主机回环端口。 |
| `metricsCadenceMs` | `5000` | 有视图订阅时共享的资源采样间隔。 |
| `metricsStalenessMs` | `15000` | 资源样本标记为过期的时间。 |

启动操作创建缺失的容器或重新启动现有容器，然后等待 Chrome。停止操作保留容器以便重新启动。设置分区在打开时以及启动、停止或刷新后读取状态，不进行轮询。生命周期失败会保持可见，刷新可重试状态查询。运行中容器的已认证查看器 URL 会单独获取，供设置中的 iframe 和链接使用；`vm_status` 不包含查看器 URL 或认证令牌。查看器凭据可授予桌面访问权限，必须保密。

模型可使用 `vm_status` 检查状态，使用 `vm_shell` 执行 shell 命令，使用 `vm_browser` 控制容器内的 Chrome，以及使用 `vm_desktop` 向镜像中的 `agent-desktop` 传递参数。Shell 和桌面命令使用镜像配置的用户及其登录环境，包括现有的桌面会话总线；这些命令依赖镜像中的 `/opt/wrap/bin/wrap-entrypoint` 辅助程序和登录配置文件。使用执行工具之前，请先通过设置启动容器。仅打开设置分区不会触发容器启动。

## Model Experience

### Tool schemas and results

#### What the model sees

四个 `vm_*` 工具声明见[工具目录](../../../docs/tool-catalog.zh.md#deepseek-aidsh-wrapvm-isolate)。根据所选操作，结果包含状态元数据、命令输出和退出码、浏览器目标数据、求值结果或页面内容。`load_vm_skill` 工具按确切名称返回六份内置 VM 指南之一，不能读取任意主机路径。指南本身不实施隔离。设置查看器及其认证令牌不属于模型上下文。

#### Token effect

启用此功能包会向适用的模型请求添加五个工具模式。工具调用会追加结果；shell 和桌面工具的标准输出与标准错误各保留末尾最多 4 MiB，然后再应用下游请求限制。浏览器页面内容和求值结果随页面与表达式变化。此插件不注入额外系统提示词。

#### KV Cache effect

配置和启用的工具集合不变时，工具声明保持稳定。启用或移除这些工具可能改变请求前缀。新工具调用与结果增加历史记录；提供方缓存和下游历史裁剪不属于此包的职责。

## Known Limitations and Deferred Work

- 容器隔离并非专用虚拟机，也不会将所有 Harness 能力置于沙箱中。只有 `vm_*` 操作使用此容器。
- 读写工作区挂载会将该主机目录暴露给容器命令和桌面应用。主机工具保留其现有访问权限。
- 此插件不限制出站网络。实际网络行为和外部连接需要在目标部署中验证。
- 现有容器会直接复用，不会重新创建其镜像、挂载或端口绑定。修改配置后，需要在插件外部明确替换容器；停止操作不会应用这些修改。
- 查看器和 CDP 端口绑定到主机回环地址。查看器需要同一主机上的浏览器；远程浏览器、HTTPS 嵌入、iframe 策略、查看器就绪情况和实际桌面交互需要实际 GUI 检查。请勿将调试端点公开。
- 组件测试和模拟引擎测试无法确认真实镜像能在特定 Docker 或 Podman 安装中成功启动。本地容器执行、已认证查看器交互和实际 CDP 命令需要明确的部署验证。
- 用户取消操作会及时停止主机等待，但不能保证立即终止容器内的进程。容器内命令超时会将执行限制在最初请求的截止时间内。
- 0.2 清单和策略流仍在开发中。绑定恢复和查看器签发尚不可用；它们不会启用受保护模式。
- 不集成 OMP，也不会自动将普通 Harness 工具重定向到此容器。
